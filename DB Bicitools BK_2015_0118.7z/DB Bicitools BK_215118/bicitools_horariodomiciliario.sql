-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `horariodomiciliario`
--

DROP TABLE IF EXISTS `horariodomiciliario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horariodomiciliario` (
  `id_horario_domiciliario` int(11) NOT NULL AUTO_INCREMENT,
  `dia` int(11) DEFAULT NULL COMMENT '2:Lunes\n3:Martes\n4:Miercoles\n5:Jueves\n6:Viernes\n7:Sábado\n1:Domingo',
  `inicio` varchar(5) DEFAULT NULL COMMENT 'hora en estilo militar 00:00 - 23:59',
  `fin` varchar(5) DEFAULT NULL COMMENT 'hora en estilo militar 00:00 - 23:59',
  `id_domiciliario` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_horario_domiciliario`),
  KEY `horariodomiciliario_1_idx` (`id_domiciliario`),
  CONSTRAINT `horario_domiciliario` FOREIGN KEY (`id_domiciliario`) REFERENCES `domiciliario` (`id_domiciliario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horariodomiciliario`
--

LOCK TABLES `horariodomiciliario` WRITE;
/*!40000 ALTER TABLE `horariodomiciliario` DISABLE KEYS */;
INSERT INTO `horariodomiciliario` VALUES (43,6,'17:00','23:00','lbadillo'),(44,2,'10:00','14:00','lbadillo'),(45,5,'17:00','23:00','lbadillo'),(46,2,'17:00','23:00','lbadillo'),(47,1,'10:00','14:00','lbadillo'),(48,3,'10:00','14:00','lbadillo'),(49,5,'17:00','23:00','lbadillo2'),(50,1,'10:00','14:00','lbadillo2'),(51,2,'17:00','23:00','lbadillo2'),(52,3,'10:00','20:00','lbadillo2'),(53,6,'17:00','23:00','lbadillo2'),(54,2,'10:00','14:00','lbadillo2'),(55,6,'07:30','23:00','lbadillo3'),(56,1,'10:00','14:00','lbadillo3'),(57,2,'10:00','14:00','lbadillo3'),(58,3,'10:00','14:00','lbadillo3'),(59,2,'07:30','23:00','lbadillo3'),(60,1,'07:30','23:00','lbadillo3'),(61,4,'07:30','23:00','lbadillo3'),(62,5,'07:30','23:00','lbadillo3'),(63,3,'17:30','21:00','jcastro2');
/*!40000 ALTER TABLE `horariodomiciliario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:01
