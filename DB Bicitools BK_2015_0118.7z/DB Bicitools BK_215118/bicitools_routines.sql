-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `mensajesusuariof`
--

DROP TABLE IF EXISTS `mensajesusuariof`;
/*!50001 DROP VIEW IF EXISTS `mensajesusuariof`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mensajesusuariof` AS SELECT 
 1 AS `idmensajeschat`,
 1 AS `fecha`,
 1 AS `mensaje`,
 1 AS `usuario`,
 1 AS `recibido`,
 1 AS `idchat`,
 1 AS `nombre`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `mensajesusuario`
--

DROP TABLE IF EXISTS `mensajesusuario`;
/*!50001 DROP VIEW IF EXISTS `mensajesusuario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `mensajesusuario` AS SELECT 
 1 AS `idmensajeschat`,
 1 AS `idchat`,
 1 AS `usuario`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `mensajesusuariof`
--

/*!50001 DROP VIEW IF EXISTS `mensajesusuariof`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mensajesusuariof` AS select ifnull(`m`.`idmensajeschat`,round((rand() * 50),0)) AS `idmensajeschat`,ifnull(`mu`.`fecha`,now()) AS `fecha`,ifnull(`mu`.`mensaje`,'') AS `mensaje`,`uc`.`usuario` AS `usuario`,ifnull(`mu`.`recibido`,0) AS `recibido`,`c`.`idchat` AS `idchat`,`c`.`nombre` AS `nombre` from (((`usuarioschat` `uc` join `chat` `c` on((`uc`.`idchat` = `c`.`idchat`))) left join `mensajesusuario` `m` on(((`uc`.`idchat` = `m`.`idchat`) and (`uc`.`usuario` = `m`.`usuario`)))) left join `mensajeschat` `mu` on((`m`.`idmensajeschat` = `mu`.`idmensajeschat`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `mensajesusuario`
--

/*!50001 DROP VIEW IF EXISTS `mensajesusuario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mensajesusuario` AS select max(`mensajeschat`.`idmensajeschat`) AS `idmensajeschat`,`mensajeschat`.`idchat` AS `idchat`,`mensajeschat`.`usuario` AS `usuario` from `mensajeschat` group by `mensajeschat`.`idchat`,`mensajeschat`.`usuario` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:02
