-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `temporal`
--

DROP TABLE IF EXISTS `temporal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temporal` (
  `columnpk` int(11) NOT NULL,
  `estring` varchar(45) DEFAULT NULL,
  `estring2` varchar(45) DEFAULT NULL,
  `edate` datetime DEFAULT NULL,
  PRIMARY KEY (`columnpk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporal`
--

LOCK TABLES `temporal` WRITE;
/*!40000 ALTER TABLE `temporal` DISABLE KEYS */;
INSERT INTO `temporal` VALUES (1,'mensaje1','ludwing','2015-09-14 16:25:24'),(2,'mensaje1','prueba','2015-09-14 16:25:56'),(3,'mensaje1','prueba2','2015-09-14 17:05:56'),(5,'mensaje1','prueba2','2015-09-14 17:08:09'),(6,'mensajeuiio','prueba9','2015-09-14 17:09:24'),(8,'mensajeuiio','prueba9','2015-09-14 17:23:40'),(9,'mensajeuiio','prueba9','2015-09-14 17:50:41'),(10,'mensajeuiio','prueba9','2015-09-15 10:31:44'),(11,'mensajeuiio','prueba9','2015-09-15 10:33:41'),(12,'mensajeuiio','prueba9','2015-09-15 11:01:26'),(14,'mensajeuiio','prueba9','2015-09-15 15:32:14'),(15,'mensajeuiio','pruebaVerificacion','2015-09-22 21:25:25'),(16,'mensajeuiio','pruebaVerificacion2','2015-09-22 21:32:08'),(17,'mensajeuiio','pruebaVerificacion2','2015-09-22 21:44:17'),(19,'mensajeuiio','pruebaVerificacion2','2015-09-25 16:30:16'),(20,'mensajeuiio','pruebaVerificacion2','2015-09-25 16:30:31');
/*!40000 ALTER TABLE `temporal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:01
