-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mensajeschat`
--

DROP TABLE IF EXISTS `mensajeschat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajeschat` (
  `idmensajeschat` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `mensaje` varchar(500) DEFAULT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `recibido` int(11) DEFAULT NULL COMMENT '1:true\n0:false',
  `idchat` int(11) DEFAULT NULL,
  PRIMARY KEY (`idmensajeschat`),
  KEY `mensajes_chat_fk_idx` (`idchat`),
  CONSTRAINT `mensajes_chat_fk` FOREIGN KEY (`idchat`) REFERENCES `chat` (`idchat`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajeschat`
--

LOCK TABLES `mensajeschat` WRITE;
/*!40000 ALTER TABLE `mensajeschat` DISABLE KEYS */;
INSERT INTO `mensajeschat` VALUES (5,'2015-10-16 00:00:00','mensaje prueba1','usuario1',1,8),(6,'2015-10-16 00:00:00','mensaje prueba2','usuario2',1,8),(7,'2015-10-16 00:00:00','mensaje prueba3','usuario3',1,8),(8,'2015-10-16 00:00:00','mensaje prueba2','usuario2',1,8),(9,'2015-10-16 00:00:00','mensaje prueba7','usuario2',1,8),(10,'2015-10-16 00:00:00','mensaje prueba733','usuario3',1,8),(11,'2015-10-16 00:00:00','mensaje prueba733','usuario3',1,9),(12,'2015-10-31 10:04:00','Lorem Ipsum22','ivan',1,10),(13,'2015-10-31 11:27:00','hola carlota','carlota',1,10),(14,'2015-11-01 09:12:00','Te saludaste a ti misma 2','ivan',1,10),(15,'2015-11-01 11:34:00','¿Cómo estás? Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','ivan',1,10),(16,'2015-11-01 00:00:00','Otro mensaje','ivan',1,10),(17,'2015-11-01 18:14:03','Test','ivan',1,10),(18,'2015-11-03 01:50:04','test2',NULL,1,10);
/*!40000 ALTER TABLE `mensajeschat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:00
