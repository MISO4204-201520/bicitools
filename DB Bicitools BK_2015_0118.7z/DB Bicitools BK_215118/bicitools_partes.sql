-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partes`
--

DROP TABLE IF EXISTS `partes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partes` (
  `idParte` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idTipo` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `idProveedor` int(11) DEFAULT NULL,
  `valor` varchar(45) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `imagen` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idParte`),
  KEY `idProducto_idx` (`nombre`),
  KEY `idProveedor_idx` (`idProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partes`
--

LOCK TABLES `partes` WRITE;
/*!40000 ALTER TABLE `partes` DISABLE KEYS */;
INSERT INTO `partes` VALUES (1,0,'pedales pato','',0,'115.210',4,NULL),(2,11,'pedales perro','',1,'115.210',4,NULL),(3,1,'marco el gato','',1,'190.000',2,NULL),(4,11,'cadena generica',NULL,1,'100000',2,NULL),(5,1,'marco el tete','',1,'10.000',9,NULL),(6,1,'marco el pelado','',1,'20.000',9,NULL),(7,0,'producto1','producto de pruebas',1,'140000',5,NULL),(8,0,'producto1','producto de pruebas',1,'140000',5,NULL),(9,0,'producto1','producto de pruebas',1,'140000',5,NULL),(10,2,'producto1','producto de pruebas',1,'140000',5,NULL),(11,0,'ttt','bbb',0,'678',15,NULL),(12,8,'plato','producto de pruebas',1,'15000',2,NULL),(13,10,'pedal 1','producto de pruebas',1,'45000',2,NULL),(14,7,'www','sdfsd',0,'777',2,NULL),(15,9,'qqqq','Lorem Ipsum',0,'56743000',20,NULL),(16,3,'Ruedas mi pez','Lorem ALgo',0,'440000',3,'http://eurolocarno.es/imagenes/2003/1/ruedas-de-bicicleta.8.jpg');
/*!40000 ALTER TABLE `partes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:00
