-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numeroIdentificacion` int(11) NOT NULL,
  `tipoIdentificacion` int(11) NOT NULL,
  `tipoPerfil` int(11) NOT NULL,
  `genero` int(11) NOT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `correo` varchar(100) NOT NULL,
  `fechaNacimiento` varchar(10) DEFAULT NULL,
  `direccionCasa` varchar(100) NOT NULL,
  `direccionTrabajo` varchar(100) DEFAULT NULL,
  `telefonoFijo` varchar(10) DEFAULT NULL,
  `telefonoMovil` varchar(10) NOT NULL,
  `facebookUser` varchar(100) DEFAULT NULL,
  `facebookToken` varchar(100) DEFAULT NULL,
  `twitterUser` varchar(100) DEFAULT NULL,
  `twitterToken` varchar(100) DEFAULT NULL,
  `usuario` varchar(10) NOT NULL,
  `contrasenia` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numeroIdentificacion_UNIQUE` (`numeroIdentificacion`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  UNIQUE KEY `usuario_UNIQUE` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (9,1025474,1,3,1,'Pepito','Perez','perfil.jpg','cjkhkarlos.parra@otrouniandes.com','2015-09-27','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','3111111','3109876542','tmarrugos',NULL,'tmarrugos',NULL,'jcastro2','fabricas'),(36,123,1,3,1,'Jose','Perez','https://facesofbellingham.files.wordpress.com/2008/06/1454.jpg','joseperez@hotmail.com','1988-09-22','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','6871234','314541267','joseperez',NULL,'joseperez',NULL,'joseperez','perez'),(38,456,1,3,1,'Jose','Perez','https://facesofbellingham.files.wordpress.com/2008/06/1454.jpg','ivan@hotmail.com','1988-09-22','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','6871234','314541267','joseperez',NULL,'joseperez',NULL,'ivan','perez'),(39,789,1,3,1,'Jose','Perez','https://facesofbellingham.files.wordpress.com/2008/06/1454.jpg','carlos@hotmail.com','1988-09-22','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','6871234','314541267','joseperez',NULL,'joseperez',NULL,'carlos','perez'),(40,987,1,3,1,'Maria','Perez','https://facesofbellingham.files.wordpress.com/2008/06/1454.jpg','maria@hotmail.com','1988-09-22','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','6871234','314541267','joseperez',NULL,'joseperez',NULL,'maria','perez'),(41,654,1,3,1,'Carlota','Perez','https://facesofbellingham.files.wordpress.com/2008/06/1454.jpg','carlota@hotmail.com','1988-09-22','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','6871234','314541267','joseperez',NULL,'joseperez',NULL,'carlota','perez'),(42,10225473,1,3,1,'Pepito','Perez','perfil.jpg','ca2rlos.parra@otrouniandes.com','2015-09-27','Carrera 1 No. 2-34 Apto. 506','Calle 7. No. 8-90 Of. 123','3111111','3109876542','tmarrugos',NULL,'tmarrugos',NULL,'2tmarrugos','fabricas');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:01
