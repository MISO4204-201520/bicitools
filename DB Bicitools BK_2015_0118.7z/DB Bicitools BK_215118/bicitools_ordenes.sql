-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ordenes`
--

DROP TABLE IF EXISTS `ordenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordenes` (
  `idOrden` int(11) NOT NULL,
  `usuario` varchar(45) DEFAULT NULL,
  `idMarco` varchar(10) DEFAULT NULL,
  `idTijera` varchar(10) DEFAULT NULL,
  `idFrenos` varchar(10) DEFAULT NULL,
  `idRuedas` varchar(10) DEFAULT NULL,
  `idManubrio` varchar(10) DEFAULT NULL,
  `idSillin` varchar(10) DEFAULT NULL,
  `idCambios` varchar(10) DEFAULT NULL,
  `idPlatoDelantero` varchar(10) DEFAULT NULL,
  `idPlatoTrasero` varchar(10) DEFAULT NULL,
  `idPedales` varchar(10) DEFAULT NULL,
  `idCadena` varchar(10) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `valor` varchar(10) DEFAULT NULL,
  `fechaHora` datetime DEFAULT NULL,
  PRIMARY KEY (`idOrden`),
  UNIQUE KEY `idOrden_UNIQUE` (`idOrden`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes`
--

LOCK TABLES `ordenes` WRITE;
/*!40000 ALTER TABLE `ordenes` DISABLE KEYS */;
INSERT INTO `ordenes` VALUES (178526,'ivan','3','0','0','0','0','0','0','0','0','0','0','P','730000','2015-11-08 01:18:06'),(370316,'ivan','3','0','0','0','0','0','0','0','0','0','0','P','730000','2015-11-08 01:17:33'),(415576,'ivan','0','0','0','0','0','0','0','0','0','0','0','P','550000','2015-11-08 01:14:22'),(568041,'ivan','0','0','0','0','0','0','0','0','0','0','0','P','550000','2015-11-08 01:18:43'),(619655,'ivan','1','4','0','0','0','0','0','0','0','0','0','P','735210','2015-11-08 01:00:07'),(659868,'toroj','1','4','0','0','0','0','0','0','0','0','0','P','645210','2015-11-07 16:39:08'),(675815,'toroj','1','4','0','0','0','0','0','0','0','0','0','P','735210','2015-11-08 00:35:13'),(831291,'toroj','1','4','0','0','0','0','0','0','0','0','0','P','735210','2015-11-08 00:56:12'),(960211,'ivan','3','0','0','0','0','0','0','0','0','13','0','P','685000','2015-11-08 02:24:45'),(972316,'ivan','3','0','0','0','0','0','0','0','0','0','0','P','730000','2015-11-08 01:15:21');
/*!40000 ALTER TABLE `ordenes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:00
