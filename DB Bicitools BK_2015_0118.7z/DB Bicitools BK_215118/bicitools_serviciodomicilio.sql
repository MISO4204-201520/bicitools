-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: bicitools
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `serviciodomicilio`
--

DROP TABLE IF EXISTS `serviciodomicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviciodomicilio` (
  `id_serviciodomicilio` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` varchar(45) DEFAULT NULL,
  `emailUsuario` varchar(200) DEFAULT NULL,
  `origen` varchar(200) DEFAULT NULL,
  `destino` varchar(200) DEFAULT NULL,
  `id_domiciliario` varchar(45) DEFAULT NULL,
  `puntos` int(11) DEFAULT NULL COMMENT 'puntos obtenidos: 0-10\n',
  `comentario` varchar(1000) DEFAULT NULL,
  `treal` varchar(5) DEFAULT NULL COMMENT 'Hora militar 00:00 - 23:59',
  `testimado` varchar(5) DEFAULT NULL COMMENT 'Hora militar 00:00 - 23:59',
  `estado` int(11) DEFAULT NULL COMMENT '1: pedido\n2: reservado\n3: terminado\n4: cancelado',
  PRIMARY KEY (`id_serviciodomicilio`)
) ENGINE=InnoDB AUTO_INCREMENT=1005 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviciodomicilio`
--

LOCK TABLES `serviciodomicilio` WRITE;
/*!40000 ALTER TABLE `serviciodomicilio` DISABLE KEYS */;
INSERT INTO `serviciodomicilio` VALUES (653,'lbadillo','ludwingbd79@gmail.com','calle 95 No 71-45','calle 7 No 44 - 32','lbadillo',NULL,NULL,'00:20','00:20',2),(703,NULL,'ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,4),(704,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(705,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(706,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(707,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(708,'j.castro','ludwingbd79@gmail.com','Universidad de los Andes','Universidad Javeriana',NULL,NULL,NULL,NULL,NULL,1),(709,'j.castro','ludwingbd79@gmail.com','Universidad de los Andes','Universidad Javeriana',NULL,NULL,NULL,NULL,NULL,1),(753,'j.castro','ludwingbd79@gmail.com','Universidad de los Andes','Universidad Javeriana',NULL,NULL,NULL,NULL,NULL,1),(803,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(853,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(854,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(903,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(953,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(954,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(1003,'j.castro','ludwingbd79@gmail.com','Universidad Javeriana','Universidad de los Andes',NULL,NULL,NULL,NULL,NULL,1),(1004,'j.castro','ludwingbd79@gmail.com','Universidad de los Andes','El Externado','jcastro2',NULL,NULL,'00:18','00:20',3);
/*!40000 ALTER TABLE `serviciodomicilio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-08  3:40:00
